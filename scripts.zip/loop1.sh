#!/usr/bin/env bash

arr=(a b c d e f)

for i in "${arr[*]}"
do
  echo $i
done

# This is comment
